<template>
    <div class="relative flex items-center justify-center w-full h-full">
        <span class="text-5xl uppercase tracking-extrawide font-thin border-b border-brand text-center">ARMA<strong class="font-bold">BOT</strong></span>
    </div>
</template>

<script>
    export default {
        data() {
            return {
                //
            }
        },

        computed: {
            //
        },

        methods: {
            //
        }
    }
</script>
